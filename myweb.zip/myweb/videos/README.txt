Add your own recordings here as:
  intro.mp4   (30-60 second self-introduction video)
  voice.mp3   (15-30 second audio clip about a hobby or your reason for
               studying web technologies)

Record these yourself on your phone, then copy them into this folder.
Delete this file once your recordings are in place.
