Add your own photos here as:
  photo1.jpg
  photo2.jpg
  photo3.jpg

Use real photos you took or have permission to share (e.g. a campus photo,
a praise-team rehearsal, a screenshot of you coding). Delete this file once
your photos are in place.
